# Bookmark

> 上传/下载书签数据到Github

Chrome Extension

使用指南：

- 登录Github，在 Settings->Personal access tokens->Generate new token 生成一个访问token

- 生成的 token 需要勾选 repo 权限，保存生成的 token

- 点击插件icon，依次输入用户名、凭据、仓库名、文件存放路径

- 如果需要记住用户数据，需要打开 Remember Me 开关

- 填写完用户数据后，便可以进行“上传”或“下载”操作

### to-do

- 监听书签修改事件自动上传更新

- 一键整理书签

- 统计书签访问情况